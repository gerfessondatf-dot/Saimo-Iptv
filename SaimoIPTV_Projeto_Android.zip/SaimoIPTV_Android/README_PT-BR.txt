SAIMO IPTV — projeto Android

Este projeto cria um aplicativo Android chamado “Saimo IPTV” que abre:
https://saimo-tv.pages.dev

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Extraia a pasta SaimoIPTV_Android.
3. No Android Studio, escolha Open e selecione essa pasta.
4. Aguarde a sincronização do Gradle.
5. Se solicitado, instale o Android SDK indicado pelo Android Studio.
6. Para gerar um APK de teste: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. O Android Studio mostrará um aviso com a opção “locate” para localizar o APK gerado.
8. Transfira o APK para o celular Android e abra-o para instalar. Talvez seja necessário permitir a instalação desse arquivo nas configurações do Android.

OBSERVAÇÕES
- É necessário ter conexão com a internet para abrir o site.
- O aplicativo exibe o site dentro de uma janela WebView.
- Este pacote contém o projeto-fonte, não um APK já compilado.
- Para publicar na Play Store, será necessário configurar assinatura e atender às regras atuais da loja.
